using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using WeatherApp.Models;

namespace WeatherApp
{
    public class Program
    {
        public static string CountryID { get; set; }

        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static async Task<Root> ConnectAsync(string city)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri($"https://community-open-weather-map.p.rapidapi.com/weather?q={city}&lang=ru&units=metric&mode=json"),
                Headers =
            {
                { "x-rapidapi-host", "community-open-weather-map.p.rapidapi.com" },
                { "x-rapidapi-key", "f4e10830c3msh80680d4c8204208p1c8c47jsn421dabd9fd90" },
            },
            };
            Root weather;
            using (var response = await client.SendAsync(request))
            {
                response.EnsureSuccessStatusCode(); ;
                string answer = await response.Content.ReadAsStringAsync();
                weather = JsonConvert.DeserializeObject<Root>(answer);
            }
            return weather;
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
